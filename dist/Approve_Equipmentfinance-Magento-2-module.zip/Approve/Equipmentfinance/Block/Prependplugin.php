<?php

namespace Approve\Equipmentfinance\Block;

use \Magento\Framework\View\Element\Template\Context;
use Approve\Equipmentfinance\Helper\Data;

/**
 * [Description Prependplugin]
 */
class Prependplugin extends \Magento\Framework\View\Element\Template
{
    /**
     * $_helperData
     *
     * @var mixed
     */
    protected $_helperData;

    /**
     * $_settings
     *
     * @var mixed
     */
    protected $_settings;

    /**
     * __construct
     *
     * @param Context $context
     * @param Data $helperData
     * @param array $data
     */
    public function __construct(
        Context $context, 
        Data $helperData,
        array $data = []
    ) {
        $this->_helperData = $helperData;
        return parent::__construct($context, $data);
    }

    /**
     * _prepareLayout
     *
     * @return void
     */
    public function _prepareLayout()
    {
        return parent::_prepareLayout();
    }
    
    /**
     * getAllApproveSettingsConfigValues
     *
     * @return void
     */
    public function getAllApproveSettingsConfigValues() {
        $settings =  (!empty($this->_settings)) ? $this->_settings : $this->_helperData->getAllApproveSettingsConfigValues();
        $this->_settings = $settings;
        return $settings;
    }

    /**
     * getAllApproveSettingsConfigValuesJSON
     *
     * @return void
     */
    public function getAllApproveSettingsConfigValuesJSON() {
        $settings =  $this->getAllApproveSettingsConfigValues();
        if (!empty($settings)) {
            $settings_json = json_encode($settings);
        } else {
            $settings_json = json_encode((object) []);
        }
        return $settings_json;
    }
}