<?php

namespace Approve\Equipmentfinance\Block\Cart;

use \Magento\Framework\View\Element\Template\Context;
use \Magento\Customer\Model\Session as CustomerSession;
use \Magento\Checkout\Model\Session as CheckoutSession;
use \Magento\Checkout\Helper\Cart;
use Approve\Equipmentfinance\Helper\Data;

/**
 * [Description ApproveCartButton]
 */
class ApproveCartButton extends \Magento\Checkout\Block\Cart\AbstractCart
{
    /**
     * $cartHelper
     *
     * @var mixed
     */
    public $cartHelper;

    /**
     * $cart_items
     *
     * @var mixed
     */
    public $cart_items_json;

    /**
     * $settings
     *
     * @var mixed
     */
    public $settings;

    /**
     * $settings_json
     *
     * @var mixed
     */
    public $settings_json;

    /**
     * $approveenabled
     *
     * @var bool
     */
    public $approveenabled = false;
    
    /**
     * $button_class
     *
     * @var string
     */
    public $button_class = "";
    
    /**
     * $button_container_class
     *
     * @var string
     */
    public $button_container_class = "";
    
    /**
     * $prefix_text
     *
     * @var string
     */
    public $prefix_text = "";
    
    /**
     * $postfix_text
     *
     * @var string
     */
    public $postfix_text = "";
    
    /**
     * $show_financing_by
     *
     * @var bool
     */
    public $show_financing_by = true;
    
    /**
     * $cart_total
     *
     * @var bool
     */
    public $cart_total = true;


    /**
     * $_helperData
     *
     * @var mixed
     */
    protected $_helperData;

    /**
     * $_settings
     *
     * @var mixed
     */
    protected $_settings;

    /**
     * __construct
     *
     * @param Context $context
     * @param CustomerSession $customerSession
     * @param CheckoutSession $checkoutSession
     * @param Cart $cartHelper
     * @param Data $helperData
     * @param array $data
     */
    public function __construct(
        Context $context,
        CustomerSession $customerSession,
        CheckoutSession $checkoutSession,
        Cart $cartHelper,
        Data $helperData,
        array $data = []
    ) {
        $this->cartHelper = $cartHelper;
        $this->_helperData = $helperData;
        // set variables for use
        // get data from our settings connection 
        $cart_total = 0;
        $settings = $this->_helperData->getAllApproveSettingsConfigValues();
        $general_settings = null;
        $display_page_settings = null;
        $list_page_settings = null;
        $cart_page_settings = null;
        $this->approveenabled = false;
        $this->button_class = "";
        $this->button_container_class = "";
        $product_name = "";
        $final_price = "";
        $price = "";
        $quantity = "";
        $item_type = "new_product";
        $this->prefix_text = "As low as $";
        $this->postfix_text = "/month. Click to Apply";
        $this->show_financing_by = true;




        $items = $this->cartHelper->getQuote()->getAllVisibleItems();
        if (!empty($items)
            && !empty($settings)
        ) {
            $settings = (object) $settings;
            $settings_json = json_encode($settings);
            $general_settings = (!empty($settings->generalsettings)) ? $settings->generalsettings : null;
            // this is the cart page so I only need cart_page_settings set below
            // $display_page_settings =  (!empty($settings->displaypagesettings)) ? $settings->displaypagesettings : null;
            // $list_page_settings =  (!empty($settings->listpagesettings)) ? $settings->listpagesettings : null;
            $cart_page_settings =  (!empty($settings->cartpagesettings)) ? $settings->cartpagesettings : null;
        }




        if ($general_settings 
            && $general_settings->approveenabled
            && ($general_settings->usedefaultsettings
                || (!empty($cart_page_settings)
                    && $cart_page_settings->showonproductcart
                )
            )
        ) {


            $cart_items = [];

            $this->approveenabled = true;


            $product_name = "";
            $final_price = "";
            $quantity = 0;

            if ($general_settings->usedefaultsettings) {
                
                if (!empty($general_settings->btnclass)) {
                    $this->button_class = $general_settings->btnclass;
                }

                if (!empty($general_settings->btncontainerclass)) {
                    $this->button_container_class = $general_settings->btncontainerclass;
                }

                if (!empty($general_settings->btnprefix)) {
                    $this->prefix_text = $general_settings->btnprefix;
                }

                if (!empty($general_settings->btnpostfix)) {
                    $this->postfix_text = $general_settings->btnpostfix;
                }

                if (!$general_settings->btnfinancingby) {
                    $this->show_financing_by = false;
                }

            } else if (!$general_settings->usedefaultsettings
                && !empty($cart_page_settings)
                && $cart_page_settings->showonproductcart
            ) {
                
                if (!empty($cart_page_settings->cartbtnclass)) {
                    $this->button_class = $cart_page_settings->cartbtnclass;
                }
                
                if (!empty($cart_page_settings->cartbtncontainerclass)) {
                    $this->button_class = $cart_page_settings->cartbtncontainerclass;
                }
                
                if (!empty($cart_page_settings->cartbtnprefix)) {
                    $this->prefix_text = $cart_page_settings->cartbtnprefix;
                }
                
                if (!empty($cart_page_settings->cartbtnpostfix)) {
                    $this->postfix_text = $cart_page_settings->cartbtnpostfix;
                }

                if (!$cart_page_settings->cartbtnfinancingby) {
                    $this->show_financing_by = false;
                }

            }





            foreach ($items as $index => $item) {
                
                $product = $item->getProduct();
                // echo "<pre>";
                // foreach($product as $pindex => $val) {
                //     echo $pindex . "\n";
                //     foreach ($val as $pvalindex => $pval) {
                //         echo $pvalindex."\n";
                //     }
                // }
                // echo "</pre>";
                $product_name = $product->getName();
                $price = $product->getFinalPrice();
                $quantity = ($item->getQty() > 0) ? $item->getQty() : 1;
                // die("<pre>".print_r($item->getQty(),true));
                $cart_total += ($price * $quantity);
                $item_type = "new_product";
                if (!empty($general_settings->btnitemtypefield)) {
                    $type_value = $product->getAttributeText($general_settings->btnitemtypefield);
                    if (stripos($type_value, "used") !== false) {
                        $item_type = "used_product";
                    }
                }

                if (!empty(trim($cart_page_settings->cartbtnitemtypefield))) {
                    $type_value = $product->getAttributeText($cart_page_settings->cartbtnitemtypefield);
                    if (stripos($type_value, "used") !== false) {
                        $item_type = "used_product";
                    }
                }

                // $keys = [];
                // foreach ($product->_data as $key => $val) {
                //     $keys[] = $key;
                // }
                $cart_items[$index] = (object) [
                    "model" => rawurlencode($product_name),
                    "price" => $price,
                    "quantity" => $quantity,
                    "type" => $item_type,
                ];
            }


           
            $this->cart_items_json = null;
            $this->cart_total = $cart_total;
            if (!empty($cart_items)) {
                $this->cart_items_json = json_encode($cart_items);
            }
            // initialize $this->settings and $this->settings_json
        }
        parent::__construct($context, $customerSession, $checkoutSession, $data);
    }

    /**
     * getAllApproveSettingsConfigValues
     *
     * @return void
     */
    public function getAllApproveSettingsConfigValues() {
        $this->settings =  (!empty($this->_settings)) ? $this->_settings : $this->_helperData->getAllApproveSettingsConfigValues();
        $this->_settings = $this->settings;
        return $this->settings;
    }

    /**
     * getAllApproveSettingsConfigValuesJSON
     *
     * @return void
     */
    public function getAllApproveSettingsConfigValuesJSON() {
        $this->settings =  $this->getAllApproveSettingsConfigValues();
        if (!empty($settings)) {
            $this->settings_json = json_encode($settings);
        } else {
            $this->settings_json = json_encode((object) []);
        }
        return $this->settings_json;
    }

}       