<?php

namespace Approve\Equipmentfinance\Block\Catalog\Product;

use \Magento\Catalog\Block\Product\AbstractProduct;
use \Magento\Catalog\Block\Product\Context;
use \Magento\Framework\ObjectManagerInterface;
use \Approve\Equipmentfinance\Helper\Data;
/**
 * [Description ApproveProductButton]
 */
class ApproveProductButton extends AbstractProduct
{
    /**
     * $button_class
     *
     * @var mixed
     */
    public $approveenabled = false;

    /**
     * $button_class
     *
     * @var mixed
     */
    public $button_class = "";
    
    /**
     * $button_container_class
     *
     * @var string
     */
    public $button_container_class = "";
    
    /**
     * $product
     *
     * @var string
     */
    public $product = "";
    
    /**
     * $product_name
     *
     * @var string
     */
    public $product_name = "";
    
    /**
     * $final_price
     *
     * @var string
     */
    public $final_price = "";
    
    /**
     * $price
     *
     * @var string
     */
    public $price = "";
    
    /**
     * $quantity
     *
     * @var string
     */
    public $quantity = "";
    
    /**
     * $item_type
     *
     * @var string
     */
    public $item_type = "";
    
    /**
     * $prefix_text
     *
     * @var string
     */
    public $prefix_text = "";
    
    /**
     * $postfix_text
     *
     * @var string
     */
    public $postfix_text = "";
    
    /**
     * $show_financing_by
     *
     * @var bool
     */
    public $show_financing_by = true;
    
    /**
     * $_helperData
     *
     * @var bool
     */
    protected $_helperData = null;
    
    /**
     * __construct
     *
     * @param Context $context
     * @param ObjectManagerInterface $objectManager
     * @param array $data
     */
    public function __construct(
        Context $context,
        Data $helperData,
        ObjectManagerInterface $objectManager,
        array $data = []
    ) {
        
        $this->_helperData = $helperData;

        $this->product = $objectManager->get('Magento\Framework\Registry')->registry('current_product');
        
        // set variables for use
        // get data from our settings connection 
        $settings = $this->_helperData->getAllApproveSettingsConfigValues();
        $general_settings = null;
        $display_page_settings = null;
        $list_page_settings = null;
        $cart_page_settings = null;
        $this->approveenabled = false;
        $this->button_class = "";
        $this->button_container_class = "";
        $this->product_name = "";
        $this->final_price = "";
        $this->price = "";
        $this->quantity = "";
        $this->item_type = "new_product";
        $this->prefix_text = "As low as $";
        $this->postfix_text = "/month. Click to Apply";
        $this->show_financing_by = true;



        if (!empty($this->product)
            && !empty($settings)
        ) {
            $settings = (object) $settings;
            $settings_json = json_encode($settings);
            $general_settings = (!empty($settings->generalsettings)) ? $settings->generalsettings : null;
            // this is the display page so I only need list_page_settings set below
            $display_page_settings =  (!empty($settings->displaypagesettings)) ? $settings->displaypagesettings : null;
            // $list_page_settings =  (!empty($settings->listpagesettings)) ? $settings->listpagesettings : null;
            // $cart_page_settings =  (!empty($settings->cartpagesettings)) ? $settings->cartpagesettings : null;
        }
        // die("<pre>".print_r($settings,true));
        if ($general_settings 
            && $general_settings->approveenabled
            && ($general_settings->usedefaultsettings
                || (!empty($display_page_settings)
                    && $display_page_settings->showonproductdisplay
                )
            )
        ) {
            $this->approveenabled = true;
            $this->product_name = $this->product->getName();
            $this->final_price = $this->product->getFinalPrice();
            $this->price = $this->product->getPrice();
            $this->quantity = ($this->product->getQty() > 0) ? $this->product->getQty() : 1;
    

            if ($general_settings->usedefaultsettings) {
                
                if (!empty($general_settings->btnclass)) {
                    $this->button_class = $general_settings->btnclass;
                }

                if (!empty($general_settings->btncontainerclass)) {
                    $this->button_container_class = $general_settings->btncontainerclass;
                }
                
                if (!empty($general_settings->btnitemtypefield)) {
                    $type_value = $this->product->getAttributeText($general_settings->btnitemtypefield);
                    if (stripos($type_value, "used") !== false) {
                        $this->item_type = "used_product";
                    }
                }

                if (!empty($general_settings->btnprefix)) {
                    $this->prefix_text = $general_settings->btnprefix;
                }

                if (!empty($general_settings->btnpostfix)) {
                    $this->postfix_text = $general_settings->btnpostfix;
                }

                if (!$general_settings->btnfinancingby) {
                    $this->show_financing_by = false;
                }

            } else if (!$general_settings->usedefaultsettings
                && !empty($display_page_settings)
                && $display_page_settings->showonproductdisplay
            ) {
                
                if (!empty($display_page_settings->displaybtnclass)) {
                    $this->button_class = $display_page_settings->displaybtnclass;
                }
                
                if (!empty($display_page_settings->displaybtncontainerclass)) {
                    $this->button_class = $display_page_settings->displaybtncontainerclass;
                }
                
                if (!empty(trim($display_page_settings->displaybtnitemtypefield))) {
                    $type_value = $this->product->getAttributeText($display_page_settings->displaybtnitemtypefield);
                    if (stripos($type_value, "used") !== false) {
                        $this->item_type = "used_product";
                    }
                }

                if (!empty($display_page_settings->displaybtnprefix)) {
                    $this->prefix_text = $display_page_settings->displaybtnprefix;
                }
                
                if (!empty($display_page_settings->displaybtnpostfix)) {
                    $this->postfix_text = $display_page_settings->displaybtnpostfix;
                }

                if (!$display_page_settings->displaybtnfinancingby) {
                    $this->show_financing_by = false;
                }

            }
        }
        parent::__construct($context, $data);
    }
}