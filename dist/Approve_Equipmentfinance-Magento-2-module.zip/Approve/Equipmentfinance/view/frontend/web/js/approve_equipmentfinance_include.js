

require([
    'jquery'
], function(jQuery) {

    

    jQuery(document).ready( function() {
        
        // check if the settings have been loaded These should be loaded when the page loads
        // IF they arent set then there is another problem/issue
        if (typeof window.approveEquipmentfinanceSettings != 'undefined'
            && typeof window.approveEquipmentfinanceSettings.generalsettings != 'undefined'
            && typeof window.approveEquipmentfinanceSettings.generalsettings.approveenabled != 'undefined'
        ) {
            window.kwipped_approve.mage_app.config = window.kwipped_approve.mage_app.config || {};
            // REQUIRED APPROVE ELEMENT VARIABLES: DO NOT DELETE OR MODIFY!!! 

            /* ================ APPROVE BigCommerce Helper Functions ================ */
            /* ================ kwipped_approve.mage_app.init ================ */
            window.kwipped_approve.mage_app.init = function () {
                var mage_app = window.kwipped_approve.mage_app,
                    config = mage_app.config;
                setTimeout(function () {
                    console.log("INIT ACTIVE");
                    window.kwipped_approve.mage_app.config.current_page = null;
                    window.kwipped_approve.mage_app.config.list_page_elements = jQuery(".approve-button-holder.approve-list-product-page .approve-button");
                    window.kwipped_approve.mage_app.config.display_page_element = jQuery(".approve-button-holder.approve-display-product-page .approve-button"); // should only have 1
                    window.kwipped_approve.mage_app.config.cart_page_element = jQuery(".approve-button-holder.approve-cart-product-page .approve-button"); // should only have 1
                    if (window.kwipped_approve.mage_app.config.list_page_elements.length > 0) {
                        window.kwipped_approve.mage_app.config.current_page = "list";
                    }
                    if (window.kwipped_approve.mage_app.config.display_page_element.length > 0) {
                        window.kwipped_approve.mage_app.config.current_page = "display";
                    }
                    if (window.kwipped_approve.mage_app.config.cart_page_element.length > 0) {
                        window.kwipped_approve.mage_app.config.current_page = "cart";
                    }

                    /*============================/
                    /=- LIST PAGE -===============/
                    /============================*/

                    // based on current page we need to process for different scenarios
                    if (window.kwipped_approve.mage_app.config.current_page == "list") {
                        // no need for qty connector or options by default. Button works as is. 
                    }
                    /*=- END LIST PAGE -==========/
                    /============================*/


                    /*============================/
                    /=- DISPLAY PAGE -============/
                    /============================*/
                    if (window.kwipped_approve.mage_app.config.current_page == "display") {
                        // need qty connector and default options.
                        window.kwipped_approve.mage_app.config.product_container_ele = jQuery(".product-info-main"); 
                        window.kwipped_approve.mage_app.config.product_qty_ele = jQuery("input[name='qty']");
                        window.kwipped_approve.mage_app.config.product_attr_ele = null;
                        if (window.kwipped_approve.mage_app.config.display_page_element.attr("approve-qty") != window.kwipped_approve.mage_app.config.product_qty_ele.val()) {
                            window.kwipped_approve.mage_app.config.display_page_element.attr("approve-qty",window.kwipped_approve.mage_app.config.product_qty_ele.val());
                        }
                        window.kwipped_approve.mage_app.config.product_qty_ele.change(function() {
                            console.log("I JUST CHANGED QTY TO ", jQuery(this).val());
                            var this_qty = jQuery(this).val();
                            window.kwipped_approve.mage_app.config.display_page_element.attr("approve-qty",this_qty);
                            mage_app.approve_update_child_teaser_total(window.kwipped_approve.mage_app.config.display_page_element);
                        });

                    }
                    /*=- END DISPLAY PAGE -=======/
                    /============================*/


                    /*============================/
                    /=- CART PAGE -===============/
                    /============================*/
                    if (window.kwipped_approve.mage_app.config.current_page == "cart") {
                        var cart_quantities = [];
                        // console.log("I AM IN THE CART");
                        // need qty connector and default options.
                        window.kwipped_approve.mage_app.config.product_container_ele = jQuery(".cart.item tr.item-info"); 
                        // console.log("ELEMENTS => ",window.kwipped_approve.mage_app.config.product_container_ele.length)
                        window.kwipped_approve.mage_app.config.product_container_ele.each(function (current_index) {
                            // console.log("INDEX => ",current_index);
                            var current_ele = jQuery(this);
                            var qty_ele = current_ele.find("input[data-role='cart-item-qty']");
                            var qty_inc = qty_ele.closest(".field").find(".qty-inc");
                            var qty_dec = qty_ele.closest(".field").find(".qty-dec");

                            cart_quantities[current_index] = Number(qty_ele.val());



                            if (qty_inc.length > 0) {
                                qty_inc.click(function(){
                                    cart_quantities[current_index] = Number(qty_ele.val());
                                    var new_qty = cart_quantities[current_index];
                                    var items = JSON.parse(decodeURIComponent(window.kwipped_approve.mage_app.config.cart_page_element.attr("approve-items")));
                                    if (items
                                        && items.length > 0
                                    ) {
                                        var current_item = items[current_index];
                                        if (current_item 
                                            && Object.keys(current_item).length > 0
                                        ) {
                                            var item = {};
                                            item.model = current_item.model;
                                            item.price = current_item.price;
                                            item.type = current_item.type;
                                            item.quantity = new_qty; // set new qty and let the update function clean and update the teaser price etc.
                                            mage_app.approve_button_update_items(window.kwipped_approve.mage_app.config.cart_page_element, item, current_index);
                                        }
                                    } 
    
                                });
                            }
                            if (qty_dec.length > 0) {
                                qty_dec.click(function(){
                                    cart_quantities[current_index] = Number(qty_ele.val());
                                    var new_qty = cart_quantities[current_index];
                                    var items = JSON.parse(decodeURIComponent(window.kwipped_approve.mage_app.config.cart_page_element.attr("approve-items")));
                                    if (items
                                        && items.length > 0
                                    ) {
                                        var current_item = items[current_index];
                                        if (current_item 
                                            && Object.keys(current_item).length > 0
                                        ) {
                                            var item = {};
                                            item.model = current_item.model;
                                            item.price = current_item.price;
                                            item.type = current_item.type;
                                            item.quantity = new_qty; // set new qty and let the update function clean and update the teaser price etc.
                                            mage_app.approve_button_update_items(window.kwipped_approve.mage_app.config.cart_page_element, item, current_index);
                                        }
                                    } 
    
                                }); 
                            }
                            console.log("QTY ELE => ",qty_ele.length);
                            qty_ele.change(function() {
                                console.log("QTY ELE CHANGED");
                                var new_qty = jQuery(this).val();
                                var items = JSON.parse(decodeURIComponent(window.kwipped_approve.mage_app.config.cart_page_element.attr("approve-items")));
                                cart_quantities[current_index] = new_qty;
                                if (items
                                    && items.length > 0
                                ) {
                                    var current_item = items[current_index];
                                    if (current_item 
                                        && Object.keys(current_item).length > 0
                                    ) {
                                        var item = {};
                                        item.model = current_item.model;
                                        item.price = current_item.price;
                                        item.type = current_item.type;
                                        item.quantity = new_qty; // set new qty and let the update function clean and update the teaser price etc.
                                        mage_app.approve_button_update_items(window.kwipped_approve.mage_app.config.cart_page_element, item, current_index);
                                    }
                                } 
                            });
                        });
                    }
                    /*=- END CART PAGE -==========/
                    /============================*/

                    // approve_update_child_teaser_total() will show or hide any APPROVE finance buttons based on the threshold set
                    mage_app.approve_update_child_teaser_total();
                }, 100);

            };

            /* ================ kwipped_approve.mage_app.approve_update_child_teaser_total ================ */
            // this function will check to see if the button should be shown/hidden based on the threshold amount(s) 
            // IF run without specifying element it will check all APPROVE finance buttons on the page
            window.kwipped_approve.mage_app.approve_update_child_teaser_total = function (ele) {
                var mage_app = window.kwipped_approve.mage_app,
                    config = mage_app.config,
                    ele = ele || jQuery(window.kwipped_approve.mage_app.config.approve_action_ele);
                // console.log("WINDOW LOCATION ",window.location);
                ele.each(function (){
                    var this_ele = jQuery(this),
                        this_grand_total = 0,
                        approve_teaser_ele = this_ele.find(window.kwipped_approve.mage_app.config.approve_teaser_ele);
                    // console.log("CURRENT LOCATION INDEXOF ", current_location.indexOf("/search.php"));
                    if (approve_teaser_ele.length > 0) {
                        if (this_ele[0].hasAttribute("approve-items")) {
                            var items = JSON.parse(decodeURIComponent(this_ele.attr("approve-items")));
                            for (var i in items) {
                                var this_item = items[i];
                                this_grand_total += Number(this_item.price) * Number(this_item.quantity);
                            }
                        } else if (this_ele[0].hasAttribute("approve-price")) {
                            this_grand_total += Number(this_ele.attr("approve-price")) * Number(this_ele.attr("approve-qty"));

                        } 
                        approve_teaser_ele.attr("approve-total", this_grand_total);
                    }
                });
            };
            /* ================ kwipped_approve.mage_app.activate_added_button ================ */
            // this function is to be called when adding a button dynamically after the initialization loads
            window.kwipped_approve.mage_app.activate_added_button = function (ele) {
                // needs to be a jQuery element
                /**
                 * EXAMPLE: (new buttons added via ajax after page is loaded and initialized) 
                 * // add to a script tag immediately after new buttons or simply initialize like below
                 * if (window.jQuery && window.kwipped_approve && window.kwipped_approve.core) {
                 *		setTimeout(function () {
                 *			jQuery("body").find(".approve_button").each(function () {
                 *				window.kwipped_approve.mage_app.activate_added_button(jQuery(this));
                *			});
                *		}, 1000);
                *	}
                */
                if (!ele.hasClass("initialized")) {
                    var teaser_ele = ele.find("[approve-function='teaser_rate']");
                    var teaser_amount = teaser_ele.attr("approve-total");
                    window.kwipped_approve.ajax.get_teaser(teaser_ele[0], teaser_amount);
                    window.kwipped_approve.core.show_hide(ele[0]);
                    window.kwipped_approve.core.activate_show_hide(ele[0]);
                    ele.addClass("initialized");
                }
            };

            /* ================ kwipped_approve.mage_app.approve_button_add_items ================ */
            // this function will allow you to add or replace a full json object of items to a button that uses the attrib approve-items
            window.kwipped_approve.mage_app.approve_button_add_items = function (ele, items) {
                var mage_app = window.kwipped_approve.mage_app;
                for (var e in items) {
                    items[e].model = encodeURIComponent(items[e].model);
                }
                ele.attr("approve-items", JSON.stringify(items));
                mage_app.approve_update_child_teaser_total(ele);
            };

            /* ================ kwipped_approve.mage_app.approve_button_add_item ================ */
            // this function will allow you to add a single json object item to a button that uses the attrib approve-items
            window.kwipped_approve.mage_app.approve_button_add_item = function (ele, item) {
                var mage_app = window.kwipped_approve.mage_app,
                    items = JSON.parse(decodeURIComponent(ele.attr("approve-items")));
                items.push(item);
                for (var e in items) {
                    items[e].model = encodeURIComponent(items[e].model);
                }
                ele.attr("approve-items", JSON.stringify(items));
                mage_app.approve_update_child_teaser_total(ele);
            };

            /* ================ kwipped_approve.mage_app.approve_button_update_items ================ */
            // this function will allow you to update item(s) on a button that uses the attrib approve-items
            window.kwipped_approve.mage_app.approve_button_update_items = function (ele, item, index) {
                var mage_app = window.kwipped_approve.mage_app,
                    index = index || 0,
                    items = JSON.parse(decodeURIComponent(ele.attr("approve-items")));
                items[index] = item;
                for (var e in items) {
                    items[e].model = encodeURIComponent(items[e].model);
                }
                ele.attr("approve-items", JSON.stringify(items));
                mage_app.approve_update_child_teaser_total(ele);
            };

            window.kwipped_approve.load_with_core = function () {
                var mage_app = window.kwipped_approve.mage_app;
                if (window.kwipped_approve.core) {
                    mage_app.init();
                } else {
                    setTimeout(function () {
                        window.kwipped_approve.load_with_core();
                    }, 500);
                }
            };
            /* ================ kwipped_approve_jqcheck ================ */
            // this function will check to see if the button should be shown/hidden based on the threshold amount(s) 
            var load_i = 0;
            var kwipped_approve_jqcheck = function (){
                var mage_app = window.kwipped_approve.mage_app;
                if(window.jQuery && window.kwipped_approve.core)  {
                    mage_app.init();
                } else {
                    // console.log(load_i + " JQUERY NOT INSTALLED YET ");
                    if (load_i < 1000) {
                        setTimeout(function () {
                            kwipped_approve_jqcheck();
                        }, 500);
                    } else {
                        return;
                    }
                    load_i ++;
                }
                // else {   
                //     console.log("JQUERY IS NOT INSTALLED YET");
                //     var script = document.createElement('script'); 
                //     document.body.appendChild(script);  
                //     script.type = 'text/javascript';
                //     script.src = "https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js";
                //     script.onload = function () {
                //         window.kwipped_approve.load_with_core();
                //     }
                // }
            };
            kwipped_approve_jqcheck();
        }
        // alert("THIS IS APPROVE_EQUIPMENTFINANCE_INCLUDE.JS BITCHES!!")
    });
});