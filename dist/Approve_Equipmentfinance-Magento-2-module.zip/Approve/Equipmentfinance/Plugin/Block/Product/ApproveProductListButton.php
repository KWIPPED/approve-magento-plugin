<?php

namespace Approve\Equipmentfinance\Plugin\Block\Product;

use \Magento\Catalog\Block\Product\AbstractProduct ;
use \Magento\Catalog\Model\Product;
use \Magento\Framework\ObjectManagerInterface;
use \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;  
use \Approve\Equipmentfinance\Helper\Data;

/**
 * [Description ApproveProductListButton]
 */
class ApproveProductListButton {

    /**
     * $_object_manager
     *
     * @var mixed
     */
    private $_object_manager;

    /**
     * $_settings_model
     *
     * @var mixed
     */
    private $_settings_model;
    
    /**
     * $_settings_collection
     *
     * @var mixed
     */
    private $_settings_collection;
    
    /**
     * $_product_collection_factory
     *
     * @var mixed
     */
    protected $_product_collection_factory;
    
    /**
     * $_helperData
     *
     * @var mixed
     */
    protected $_helperData;

    /**
     * __construct
     *
     * @param ObjectManagerInterface $object_manager
     * @param CollectionFactory $product_collection_factory
     * @param Data $helperData
     */
    public function __construct(
        ObjectManagerInterface $object_manager,
        CollectionFactory $product_collection_factory,
        Data $helperData
    ) {
        $this->_object_manager = $object_manager;
        // $this->_settings_model = $this->_object_manager->create('Approve\Equipmentfinance\Model\Settings');
        // $this->_settings_collection = $this->_settings_model->getCollection();
        // $this->_product_collection_factory = $product_collection_factory; 
        $this->_helperData = $helperData;
    }

    /**
     * getProductCollection
     *
     * @return void
     */
    public function getProductCollection()
    {
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->setPageSize(3); // fetching only 3 products
        return $collection;
    }

    /**
     * afterGetProductDetailsHtml
     *
     * @param AbstractProduct $subject
     * @param mixed $result
     * @param Product $product
     * 
     * @return void
     */
    public function afterGetProductDetailsHtml(
        AbstractProduct $subject,
        $result,
        Product $product
    ) {
        // $result contains the original html data 
        
        // get the product data from $product
        // if no product simply return the html we have
        if (!$product) {
            return $result;
        }
        // set variables for use
        // get data from our settings connection 
        $settings = $this->_helperData->getAllApproveSettingsConfigValues();
        $general_settings = null;
        $display_page_settings = null;
        $list_page_settings = null;
        $cart_page_settings = null;
        if (!empty($settings)) {
            $settings = (object) $settings;
            $settings_json = json_encode($settings);
            $general_settings = (!empty($settings->generalsettings)) ? $settings->generalsettings : null;
            // this is the list page so I only need list_page_settings set below
            // $display_page_settings =  (!empty($settings->displaypagesettings)) ? $settings->displaypagesettings : null;
            $list_page_settings =  (!empty($settings->listpagesettings)) ? $settings->listpagesettings : null;
            // $cart_page_settings =  (!empty($settings->cartpagesettings)) ? $settings->cartpagesettings : null;
        }
        // die("<pre>".print_r($settings,true));
        if ($general_settings 
            && $general_settings->approveenabled
            && ($general_settings->usedefaultsettings
                || (!empty($list_page_settings)
                    && $list_page_settings->showonproductlist
                )
            )
        ) {

            $button_class = "";
            $button_container_class = "";
            $product_name = $product->getName();
            $final_price = (($product->getFinalPrice() > 0) ? $product->getFinalPrice() : 1);
            $price = $product->getPrice();
            $quantity = ($product->getQty() > 0) ? $product->getQty() : 1;
            $item_type = "new_product";
            $prefix_text = "As low as $";
            $postfix_text = "/month. Click to Apply";
            $show_financing_by = true;

            if ($general_settings->usedefaultsettings) {
                
                if (!empty($general_settings->btnclass)) {
                    $button_class = $general_settings->btnclass;
                }

                if (!empty($general_settings->btncontainerclass)) {
                    $button_container_class = $general_settings->btncontainerclass;
                }
                
                if (!empty($general_settings->btnitemtypefield)) {
                    $type_value = $product->getAttributeText($general_settings->btnitemtypefield);
                    if (stripos($type_value, "used") !== false) {
                        $item_type = "used_product";
                    }
                }

                if (!empty($general_settings->btnprefix)) {
                    $prefix_text = $general_settings->btnprefix;
                }

                if (!empty($general_settings->btnpostfix)) {
                    $postfix_text = $general_settings->btnpostfix;
                }

                if (!$general_settings->btnfinancingby) {
                    $show_financing_by = false;
                }

            } else if (!$general_settings->usedefaultsettings
                && !empty($list_page_settings)
                && $list_page_settings->showonproductlist
            ) {
                
                if (!empty($list_page_settings->listbtnclass)) {
                    $button_class = $list_page_settings->listbtnclass;
                }
                
                if (!empty($list_page_settings->listbtncontainerclass)) {
                    $button_class = $list_page_settings->listbtncontainerclass;
                }
                
                if (!empty(trim($list_page_settings->listbtnitemtypefield))) {
                    $type_value = $product->getAttributeText($list_page_settings->listbtnitemtypefield);
                    if (stripos($type_value, "used") !== false) {
                        $item_type = "used_product";
                    }
                }

                if (!empty($list_page_settings->listbtnprefix)) {
                    $prefix_text = $list_page_settings->listbtnprefix;
                }
                
                if (!empty($list_page_settings->listbtnpostfix)) {
                    $postfix_text = $list_page_settings->listbtnpostfix;
                }

                if (!$list_page_settings->listbtnfinancingby) {
                    $show_financing_by = false;
                }

            }
           

            $approve_button = "
                <div class='approve-button-holder approve-list-product-page {$button_container_class}' 
                    style='z-index:999999999999999 display:none;' 
                    approve-container 
                    approve-function='hide_below_total'
                    approve-total='{$final_price}'
                >
                    <span 
                        class='approve-button approve-button-single {$button_class}' 
                        style='display:none;' 
                        approve-function='embedded_app' 
                        approve-action='add_to_app' 
                        approve-model='{$product_name}' 
                        approve-price='{$final_price}' 
                        approve-qty='{$quantity}' 
                        approve-item-type='{$item_type}' 
                    >
                    {$prefix_text}<span approve-function='teaser_rate' approve-total='{$final_price}' class='approve-teaser-rate'></span>{$postfix_text}
                    </span>
            ";
            if ($show_financing_by) {
                $approve_button .= "
                <div class='financingby' approve-function='info'>
                    <div>Financing By&nbsp;</div>
                    <img style='width:auto;margin-bottom:6px;' src='https://cdn.approvefinancing.com/images/approve-logo-embed.png'>
                </div>
                ";
            }
            $approve_button .= "<div />";
            $result .= $approve_button;
        }
        return $result;
    }
    
}