<?php

namespace Approve\Equipmentfinance\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

/**
 * [Description Data]
 */
class Data extends AbstractHelper
{

    const XML_PATH_APPROVESETTINGS = 'approvesettings/';

    /**
     * getConfigValue
     *
     * @param mixed $field
     * @param null $storeId
     * 
     * @return void
     */
    public function getConfigValue($field, $storeId = null)
    {
        return $this->scopeConfig->getValue(
            $field, ScopeInterface::SCOPE_STORE, $storeId
        );
    }

    /**
     * getSettingConfig
     *
     * @param mixed $code
     * @param null $storeId
     * 
     * @return void
     */
    public function getSettingConfig($code, $storeId = null)
    {
        return $this->getConfigValue(self::XML_PATH_APPROVESETTINGS .'setting/'. $code, $storeId);
    }

    /**
     * getGeneralSettingConfig
     *
     * @param mixed $code
     * @param null $storeId
     * 
     * @return void
     */
    public function getGeneralSettingConfig($code, $storeId = null)
    {

        return $this->getConfigValue(self::XML_PATH_APPROVESETTINGS .'generalsettings/'. $code, $storeId);
    }

    /**
     * getDisplayPageSettingConfig
     *
     * @param mixed $code
     * @param null $storeId
     * 
     * @return void
     */
    public function getDisplayPageSettingConfig($code, $storeId = null)
    {

        return $this->getConfigValue(self::XML_PATH_APPROVESETTINGS .'displaypagesettings/'. $code, $storeId);
    }

    /**
     * getListPageSettingConfig
     *
     * @param mixed $code
     * @param null $storeId
     * 
     * @return void
     */
    public function getListPageSettingConfig($code, $storeId = null)
    {

        return $this->getConfigValue(self::XML_PATH_APPROVESETTINGS .'listpagesettings/'. $code, $storeId);
    }

    /**
     * getCartPageSettingConfig
     *
     * @param mixed $code
     * @param null $storeId
     * 
     * @return void
     */
    public function getCartPageSettingConfig($code, $storeId = null)
    {

        return $this->getConfigValue(self::XML_PATH_APPROVESETTINGS .'cartpagesettings/'. $code, $storeId);
    }

    /**
     * getAllApproveSettingsConfigValues
     *
     * @param null $storeId
     * 
     * @return void
     */
    public function getAllApproveSettingsConfigValues($storeId = null)
    {

        $return = (object) [];

        $generalsettings = $this->getConfigValue(self::XML_PATH_APPROVESETTINGS .'generalsettings', $storeId);
        $return->generalsettings = (!empty($generalsettings)) ? (object) $generalsettings : (object) [];

        $displaypagesettings = $this->getConfigValue(self::XML_PATH_APPROVESETTINGS .'displaypagesettings', $storeId);
        $return->displaypagesettings = (!empty($displaypagesettings)) ? (object) $displaypagesettings : (object) [];

        $listpagesettings = $this->getConfigValue(self::XML_PATH_APPROVESETTINGS .'listpagesettings', $storeId);
        $return->listpagesettings = (!empty($listpagesettings)) ? (object) $listpagesettings : (object) [];

        $cartpagesettings = $this->getConfigValue(self::XML_PATH_APPROVESETTINGS .'cartpagesettings', $storeId);
        $return->cartpagesettings = (!empty($cartpagesettings)) ? (object) $cartpagesettings : (object) [];

        return $return;
    }
}
